import Link from "next/link";
import { UserButton } from "@clerk/nextjs";
import { categories } from "@/lib/sample-data";

export default function Sidebar() {
  return (
    <aside className="flex h-full w-64 shrink-0 flex-col border-l border-ink-line bg-ink text-paper">
      <div className="border-b border-ink-line px-6 py-6">
        <p className="font-display text-base tracking-wide2">
          The Enterprise Prompt
        </p>
        <p className="clause-mark mt-1">فهرس الأبواب</p>
      </div>

      <nav className="flex-1 px-3 py-4">
        <Link
          href="/dashboard"
          className="block rounded px-3 py-2 font-mono text-xs tracking-wide2 text-slate transition-colors hover:bg-ink-soft hover:text-paper"
        >
          نظرة عامة
        </Link>

        <div className="mt-4 border-t border-ink-line pt-4">
          {categories.map((cat) => (
            <Link
              key={cat.slug}
              href={`/dashboard/${cat.slug}`}
              className="flex items-baseline justify-between rounded px-3 py-2.5 text-sm text-paper/90 transition-colors hover:bg-ink-soft"
            >
              <span>{cat.title}</span>
              <span className="clause-mark text-[10px]">{cat.chapter}</span>
            </Link>
          ))}
        </div>
      </nav>

      <div className="flex items-center gap-3 border-t border-ink-line px-6 py-5">
        <UserButton afterSignOutUrl="/" />
        <span className="font-mono text-xs text-slate">حسابي</span>
      </div>
    </aside>
  );
}
