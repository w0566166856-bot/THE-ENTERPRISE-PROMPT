import { Lock } from "lucide-react";
import { Prompt } from "@/types";

function formatArabicDate(iso: string): string {
  return new Date(iso).toLocaleDateString("ar-SA", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

export default function PromptCard({ prompt }: { prompt: Prompt }) {
  return (
    <article
      className="group relative border border-paper-line bg-white p-5 transition-shadow hover:shadow-[0_1px_0_0_theme(colors.brass.DEFAULT)]"
      aria-disabled={prompt.locked}
    >
      <div className="flex items-start justify-between">
        <span className="clause-mark">المادة {prompt.clauseNumber}</span>
        {prompt.locked && (
          <span className="flex items-center gap-1 font-mono text-[10px] tracking-wide2 text-slate">
            <Lock size={12} aria-hidden="true" />
            ضمن باقة أعلى
          </span>
        )}
      </div>

      <h3 className="mt-3 font-display text-lg leading-snug text-ink">
        {prompt.title}
      </h3>
      <p className="mt-2 text-sm leading-7 text-slate">{prompt.summary}</p>

      <div className="seal-divider my-4" />

      <div className="flex items-center justify-between font-mono text-[11px] text-slate">
        <span>آخر تحديث: {formatArabicDate(prompt.updatedAt)}</span>
        <span>{prompt.usageCount} استخدام هذا الشهر</span>
      </div>

      <button
        disabled={prompt.locked}
        className="mt-4 w-full border border-ink py-2.5 font-mono text-xs tracking-wide2 text-ink transition-colors enabled:hover:bg-ink enabled:hover:text-paper disabled:cursor-not-allowed disabled:border-paper-line disabled:text-slate"
      >
        {prompt.locked ? "ترقية للوصول" : "استخدام الأمر"}
      </button>
    </article>
  );
}
